<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            font-size: larger;
        }
        /*Accedemos a todos los segundos td de cada tr de la tabla*/
        table tr td:nth-child(2){
            padding-left: 2em;
        }
        .button{
            margin-top: 1em;
            width: 8em;
        }
    </style>
</head>
<body>
    <div class="contenedor">
        <h2>Añadir Contacto</h2>
        <form method="post">
            <table>
                <tr>
                    <td><label for="nombre">Nombre:</label></td>
                    <td><input type="text" id="nombre" name="nombre" required></td>
                </tr>
                <tr>
                    <td><label for="apellido">Apellido:</label></td>
                    <td><input type="text" id="apellido" name="apellido" required></td>
                </tr>
                <tr>
                    <td><label for="tel">Teléfono</label></td>
                    <td><input type="tel" id="tel" name="tel" required></td>
                </tr>
            </table>
            <input type="submit" value="Añadir" class='button'>
            <a href="./index.php"><input type="button" value="Visualizar" class='button'></a>
        </form>
    </div>
</body>
</html>

<?php
use MongoDB\Operation\InsertMany;
    // Accederemos en el caso de que el envío haya sido por POST
    if($_SERVER['REQUEST_METHOD'] = 'POST'){
        // Y volveremos a acceder si han sido establecidos todos los campos
        if(isset($_POST['nombre']) && isset( $_POST['apellido']) && isset( $_POST['tel'])){
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $tel = $_POST['tel'];

            // Con esto podremos usar la librería php en el proyecto
            require './vendor/autoload.php';
            // Primero instanciamos la clase MongoDB, con los parámetros predeterminados (localhost y en el puerto 27017)
            $connect = new MongoDB\Client;
            $dataBase = $connect->local; // Accedemos a la bd, que en nuestro caso se llama 'local'
            $collection = $dataBase->contactos; // En este caso creamos una colección, dónde guardaremos los contactos

            // Ahora insertamos los datos; al introducir el nombre, apellido y teléfono
            $insertData = $collection->insertOne([
                'Nombre'=> $nombre,
                'Apellido'=> $apellido,
                'Tel'=> $tel
            ]);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table{
            margin: auto;
        }
        th{
            width: 15em;
            font-size: large;
        }
    </style>
</head>
<body>
    <div class="contenedor">
        <h1>CRUD con MONGODB</h1>
        <a href="./addContact.php"><button>Añadir Contacto</button></a>
        <a href="./searchName.php"><button>Buscar Contacto</button></a><br><br>
        <table border="1px solid" cellspacing= '0'>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Teléfono</th>
            </tr>
            <?php
                // Con esto podremos usar la librería php en el proyecto
                require './vendor/autoload.php';
                // Primero instanciamos la clase MongoDB, con los parámetros predeterminados (localhost y en el puerto 27017)
                $connect = new MongoDB\Client;
                $collection = $connect->local->contactos; // Podemos acceder directamente a la colección
                $datos = $collection->find(); // Con esto obtendremos los datos que se encuentran en nuestra colección 'contactos'
                
                // Recorremos con ayuda del foreach todos los datos que se encuentre en 'contactos'
                foreach ($datos as $documento) {
                    // Creamos una tabla y en ella pondremos los datos 
                    echo "
                        <tr>
                            <td> " . $documento['Nombre'] . "</td>
                            <td> " . $documento['Apellido'] . "</td>
                            <td> " . $documento['Tel'] . "</td>
                        </tr>";
                }
            ?>
        </table>
        
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            font-size: larger;
        }
        .button{
            width: 8em;
        }
    </style>
</head>
<body>
    <div class="contenedor">
        <h2>Buscar Contacto</h2>
        <form method="post">
            <table>
                <tr>
                    <th><label for="nombre">Nombre</label></th>
                    <td><input type="text" id="nombre" name='nombre'></td>
                    <td><input type="submit" value="Buscar" class='button'></td>
                    <td><a href="./index.php"><input type="button" value="Volver" class='button'></a></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>
<?php
    // Accederemos en el caso de que el envío haya sido por POST
    if($_SERVER['REQUEST_METHOD'] = 'POST'){
        // Y volveremos a acceder si han sido establecidos todos los campos
        if(isset($_POST['nombre'])){
            // Con esto podremos usar la librería php en el proyecto
            require './vendor/autoload.php';
            // Primero instanciamos la clase MongoDB, con los parámetros predeterminados (localhost y en el puerto 27017)
            $connect = new MongoDB\Client;
            $collection = $connect->local->contactos;
            $nombre = $_POST['nombre'];

            // Procedemos a buscar el nombre que el usuario haya escrito en nuestra colección
            $find = $collection->find(['Nombre' => $nombre])->toArray();
            // Crearemos una condición en la que comprobaremos si el nombre está vacío o no 
            if(!empty($find)){
                echo "<br>
                <table border='1px solid' cellspacing= '0'>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Teléfono</th>
                </tr>";
                foreach($find as $documento){
                    echo "
                        <tr>
                            <td> " . $documento['Nombre'] . "</td>
                            <td> " . $documento['Apellido'] . "</td>
                            <td> " . $documento['Tel'] . "</td>
                        </tr>
                    ";
                }
                echo"</table>";
            }else{
                echo "<p style='color: red;'>No se a encontrado el nombre '$nombre'</p>";
            }
            
        }
    }
?>